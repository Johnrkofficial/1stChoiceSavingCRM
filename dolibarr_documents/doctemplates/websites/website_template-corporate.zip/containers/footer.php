<?php
// File generated to wrap the alias page - DO NOT MODIFY - It is just a wrapper to real page
global $dolibarr_main_data_root;
if (empty($dolibarr_main_data_root)) require './page187.tpl.php'; else require $dolibarr_main_data_root.'/website/'.$website->ref.'/page187.tpl.php';
?>
